<?php

/*
 * Plugin Name:       Woocommerce product delivery date
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Handle the Woocommerce product delivery custom date with this plugin.
 * Version:           1.10.3
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Tm
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       my-basics-plugin
 * Domain Path:       /languages
 */

?>

<?php

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

add_action("init", "tm_product_delivery_date_assets");

    function tm_product_delivery_date_assets() {

wp_enqueue_style("bootstrap",   plugins_url() . "/tm_woo_delivery_date/css/bootstrap.css", '');

wp_enqueue_style("bootstrap-datepicker",   "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css", '');


wp_enqueue_script('jquery.min.js',   'https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js', '', true);

wp_enqueue_script('bootstrap.min.js',   'https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.min.js', '', true);

wp_enqueue_script('bootstrap-datepicker.min.js',   'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js', '', true);
        
        
}




      // Put your plugin code here
    add_action('woocommerce_after_order_notes', 'custom_checkout_field');

    function custom_checkout_field($checkout)

{

echo '<section class="container">
  
    <label for="date" class="col-1 col-form-label"> Delivery Date</label>
    <div class="col-5">
      <div class="input-group date" id="tm">
        <input type="text" name="tm_delivery_date" class="form-control" id="tm_datepicker" autocomplete="off" />
        <span class="input-group-append">
          <span class="input-group-text bg-light d-block">
            <i class="fa fa-calendar"></i>
          </span>
        </span>
      </div>
    </div>
</section>';
    
    ?>
    <script language="javascript">
    $('#tm_datepicker').datepicker({
   format: 'yyyy-mm-dd' 
});
    </script>
<?php
}

 



add_action('woocommerce_checkout_update_order_meta', 'custom_checkout_field_update_order_meta');
     
}

function custom_checkout_field_update_order_meta($order_id)

{

if (!empty($_POST['tm_delivery_date'])) {

update_post_meta($order_id, 'tm_delivery_date',sanitize_text_field($_POST['tm_delivery_date']));

}



add_action( 'plugins_loaded', 'setup_so_22237380' );

function setup_so_22237380() 
{
    // Just to make clear how the filters work
    $posttype = "shop_order";

    // Priority 20, with 1 parameter (the 1 here is optional)
    add_filter( "manage_edit-{$posttype}_columns", 'column_set_so_22237380', 20, 1 ); 

    // Priority 20, with 2 parameters
    add_action( "manage_{$posttype}_posts_custom_column", 'column_display_so_22237380', 20, 2 ); 

    // Default priority, default parameters (zero or one)
    add_filter( "manage_edit-{$posttype}_sortable_columns", 'column_sort_so_22237380' ); 
}


function column_set_so_22237380( $columns )
{
    $columns['order_sales'] = "Sales";
    return $columns;
}


function column_display_so_22237380( $column_name, $post_id ) 
{
    if ( 'order_sales' != $column_name )
        return;

    $sales_information = 'Your custom get_order_sales_information($post_id)';

    if ( $sales_information )
        echo "<strong style='color:#f00;'> $sales_information </strong>";
}

function column_sort_so_22237380( $columns ) 
{
    $columns['order_sales'] = 'order_sales';
    return $columns;
}



}

add_filter( 'manage_edit-shop_order_columns', 'custom_shop_order_column', 20 );
function custom_shop_order_column($columns)
{
    $reordered_columns = array();

    // Inserting columns to a specific location
    foreach( $columns as $key => $column){
        $reordered_columns[$key] = $column;
        if( $key ==  'order_status' ){
            // Inserting after "Status" column
            $reordered_columns['my-column1'] = __( 'Delivery Date','theme_domain');
        }
    }
    return $reordered_columns;
}


// Adding custom fields meta data for each new column (example)
add_action( 'manage_shop_order_posts_custom_column' , 'custom_orders_list_column_content', 20, 2 );
function custom_orders_list_column_content( $column, $post_id )
{
    switch ( $column )
    {
        case 'my-column1' :
            // Get custom post meta data
            $my_var_one = get_post_meta( $post_id, 'tm_delivery_date', true );
            if(!empty($my_var_one))
                echo $my_var_one;

            // Testing (to be removed) - Empty value case
            else
                echo '<small>(<em>no value</em>)</small>';

            break;

        
    }
}


?>