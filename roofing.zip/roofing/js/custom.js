jQuery(window).scroll(function () {
  if (jQuery(this).scrollTop() > 70) {
    jQuery(".header-area").addClass("fix");
  } else {
    jQuery(".header-area").removeClass("fix");
  }
});