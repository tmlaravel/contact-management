      <footer class="footer-area">
        <div class="container">
         <div class="footer-area-top">
          <div class="row">
            <div class="col-lg-8">
              <div class="row">
                <div class="col-lg-4">
                  <div class="footer_wizget">
                    <ul>
                      <li><a href="#">Roof Repair</a></li>
                      <li><a href="#">New Roof</a></li>
                      <li><a href="#">Leak Repairs</a></li>
                      <li><a href="#">Roof Inspection</a></li>
                      <li><a href="#">Roof Framing</a></li>
                      <li><a href="#">Skylight Services</a></li>
                    </ul>
                  </div>
                </div>
                <div class="col-lg-4">
                  <div class="footer_wizget">
                    <ul>
                      <li><a href="#">Chimney Inspection</a></li>
                      <li><a href="#">Chimney Repair</a></li>
                      <li><a href="#">Chimney Cleaning</a></li>
                      <li><a href="#">Chimney Relining</a></li>
                      <li><a href="#">Chimney Caps</a></li>
                      <li><a href="#">Covers and Crowns</a></li>
                    </ul>
                  </div>
                </div>
                <div class="col-lg-4">
                  <div class="footer_wizget">
                    <ul>
                      <li><a href="#">Siding Repair</a></li>
                      <li><a href="#">Siding Install</a></li>
                      <li><a href="#">Siding Leak Repair</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
             <div class="col-lg-4">
              <div class="row">
                <div class="col-lg-6">
                  <div class="footer_wizget">
                    <ul>
                      <li><a href="#">Paver Patios</a></li>
                      <li><a href="#">Steps</a></li>
                      <li><a href="#">Retaining Walls</a></li>
                      <li><a href="#">Concrete Work</a></li>
                      <li><a href="#">Porches</a></li>
                      <li><a href="#">Waterproofing</a></li>
                    </ul>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="footer_wizget">
                    <ul>
                      <li><a href="#">Deck Framing</a></li>
                      <li><a href="#">Deck Railing</a></li>
                      <li><a href="#">Deck Stairs</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="footerline"></div>
        <div class="footerline"></div>
        <div class="subscribe_area">
          <div class="d-flex align-items-center subscribetotal">
            <h4><?php echo get_field('subscribe_title_text', 'option'); ?></h4>
            <form method="post" action="https://webtechnomind.in/work/roofing/?na=s">
            <div class="subscribe_formbox d-flex">

              <!-- <input type="text" class="form-control" name="" placeholder="E-Mail Address">
              <button><img src="<?php echo get_template_directory_uri(); ?>/images/rightarrow.png" alt="#"></button> -->




<input type="hidden" name="nlang" value="">

<input type="text" class="form-control" type="email" name="ne" id="tnp-1" value="" required placeholder="E-Mail Address">

<button type="submit" class="tnp-submit">
  <img src="<?php echo get_template_directory_uri(); ?>/images/rightarrow.png" alt="#">
</button>



            </div>
</form>

          </div>
          <p><?php echo get_field('subscribe_content_text', 'option'); ?></p>
        </div>
        <div class="footer-bottom d-flex justify-content-between">
          <div class="footer-bottom-left d-flex align-items-center">
            <div class="logofooter">
              <img src="<?php echo get_field('logo', 'option'); ?>" alt="#">
            </div>
            <a class="btn-Privacy" href="#">Privacy Policy <img src="<?php echo get_template_directory_uri(); ?>/images/rightarrow.png" alt="#"></a>
          </div>
          <div class="followus_area">
            <h5>Follow us on</h5>
            <ul class="d-flex">
<?php if( have_rows('social_area', 'option') ): ?>
    <?php while( have_rows('social_area', 'option') ): the_row(); ?>
                  
<li><a href="<?php echo get_sub_field('link'); ?>" target="_blank"><i class="fa-brands <?php echo get_sub_field('icon_font_awesome_code'); ?>"></i></a></li>


    <?php endwhile; ?>
<?php endif; ?>
              
            </ul>
          </div>
        </div>
        </div>
      </footer>
    </div>
  
    <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script>
      $('#searvices-slider').owlCarousel({
        navigation : true,     
        autoplay: true,
        autoplayTimeout:5000,
        loop: true,
        margin:18,
        nav:true,
        dots:false,
        responsive: {
          0:{
            items:2
          },
          480:{
            items:2
          },
          640:{
            items:2
          },
          768:{
            items:3
          },
          991:{
            items:3
          },
          1199:{
            items:4
          },
        }
      });
      $('.details-carousel').owlCarousel({
        navigation : true,     
        autoplay: true,
        autoplayTimeout:5000,
        loop: true,
        margin:0,
        nav:true,
        dots:false,
        responsive: {
          0:{
            items:1
          },
          1199:{
            items:1
          },
        }
      });
    </script>
    <script type="text/javascript">
      $.fn.moveIt = function(){
  var $window = $(window);
  var instances = [];
  
  $(this).each(function(){
    instances.push(new moveItItem($(this)));
  });
  


  // $(document).ready(function() {
	// 	$(window).scroll(function(e){
  //     var scrollTop = $window.scrollTop();
     
  //   });
  // });


  window.addEventListener('scroll', function(){
    var scrollTop = $window.scrollTop();
    instances.forEach(function(inst){
      inst.update(scrollTop);
    });

    

  }, {passive: true});
}

var moveItItem = function(el){
  this.el = $(el);
  this.speed = parseInt(this.el.attr('data-scroll-speed'));
};

moveItItem.prototype.update = function(scrollTop){
  this.el.css('transform', 'translateY(' + -(scrollTop / this.speed) + 'px)');

  var docHeight = $(document).height();
  var winHeight = $('.header_panel').height();
  var scrollPercent = (scrollTop) / (docHeight - winHeight);
  var scrollPercentRounded =  Math.round(scrollPercent*100);
  if(Math.round(-52.7777 + scrollPercent*4.2*100) < 0){
    $('.header_panel').attr('data-scroll-completed', 'false');
    $('.header_panel').css('transform', 'translateX(' +  Math.round(-52.7777 + scrollPercent*4.2*100) + '%)');
    $('.menu-btn').css('opacity', 0);
    $('.menu-btn').css('visibility', 'hidden');
  }else{
    $('.header_panel').attr('data-scroll-completed', 'true');
    $('.header_panel').css('transform', 'translateX(0%)');
    $('.menu-btn').css('opacity', 1);
    $('.menu-btn').css('visibility', 'visible');
  }
  if(Math.round(-22.2222 + scrollPercent*2*100) < 0){
    $('.header_cover').attr('data-scroll-completed', 'false');
    $('.header_cover').css('transform', 'translateX(' +  Math.round(-22.2222 + scrollPercent*2*100) + '%)');
  }else{
    $('.header_cover').attr('data-scroll-completed', 'true');
    $('.header_cover').css('transform', 'translateX(0%)');
  }

  if(Math.round(scrollPercent*100) > 0){
    $('.header_navbar').attr('data-scroll-completed', 'false');
    $('.header_navbar').css('transform', 'translateX(' +  Math.round(scrollPercent*100) + '%)');
    $('.header_navbar').css('opacity', 1 - Math.round(scrollPercent*100)/10 );
  }else{
    $('.header_navbar').css('transform', 'translateX(0%)');
    $('.header_navbar').css('opacity', 1);
  }
};

  // Initialization
  $(function(){
    $('[data-scroll-speed]').moveIt();
  });

  menuClick = false;
  function menuOpen(){
    if(menuClick == true){
      menuClick = false;
      $('.header_panel').attr('data-scroll-completed', 'true');
      $('.header_panel').css('transform', 'translateX(0%)');
      $('.header_cover').attr('data-scroll-completed', 'true');
      $('.header_cover').css('transform', 'translateX(0%)');

      $('.header_navbar').css('transform', 'translateX(0%)');
      $('.header_navbar').css('opacity', 0);
      $('body').css('overflow', 'auto');
      $('.main').css('transform', 'unset');
      $('.main').css('pointer-events', 'auto');
      $('.main').css('opacity', 1);
    }else{
      menuClick = true;
      $('.header_panel').attr('data-scroll-completed', 'false');
      $('.header_panel').css('transform', 'translateX(-22%)');
      $('.header_cover').attr('data-scroll-completed', 'false');
      $('.header_cover').css('transform', 'translateX(-22%)');

      $('.header_navbar').css('transform', 'translateX(0%)');
      $('.header_navbar').css('opacity', 1);
      $('body').css('overflow', 'hidden');
      $('.main').css('transform', 'translateX(-22%)');
      $('.main').css('pointer-events', 'none');
      $('.main').css('opacity', 0.5);
      
    }
    
    
  }

    </script>
     <script>
    var divs = $('.homepage-intro_container'),
    limit = 600;  /* scrolltop value when opacity should be 0 */

$(window).on('scroll', function() {
   var st = $(this).scrollTop();

   /* avoid unnecessary call to jQuery function */
   if (st <= limit) {
     divs.css({ 'opacity' : (1 - st/limit)});
   }
});
  </script>
  <?php wp_footer(); ?>
  </body>
</html>