<?php
/**
* Template Name: About Page
*/

?>

<?php get_header(); ?>
        <main class="main innermain">
          <div class="container">
            <div class="homepage-intro_container">
            	<a href="<?php echo get_home_url(); ?>">
              <div class="homepage-intro_brand">
                <img src="<?php echo get_field('logo', 'option'); ?>" alt="#">
              </div>
          </a>
              <!-- breadcrumb start -->
              <nav>
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo home_url(); ?>">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">About</li>
                </ol>
              </nav>
              <!-- breadcrumb stop -->
              <!-- inner banner start -->
              <div class="inner-banner-area">
                <div class="row">
                  <div class="col-lg-6 order-2">
                <div class="inner-banner-img d-flex">
                  <img src="<?php echo get_the_post_thumbnail_url($post_id); ?>" alt="#">
                </div>
              </div>
              <div class="col-lg-6 order-1">
                <div class="inner-banner-contain">

<?php

$my_postid = $post_id;//This is page id or post id
$content_post = get_post($my_postid);
$content = $content_post->post_content;
$content = apply_filters('the_content', $content);
$content = str_replace(']]>', ']]&gt;', $content);
echo $content;

?>

                </div>
              </div>
              </div>
              </div>
              <!-- inner banner stop -->
            </div>
            <!-- inner about area start -->
            <div class="inner-about-body-area m-50">
                <div class="about-tag">
<?php echo get_field('list_content',$post_id); ?>
                </div>
                <div class="inner-about-video-box">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/inner-about-video-bg.jpg" alt="#" title="" />
                    <div class="video-main">
                        <div class="promo-video">
                          <div class="waves-block">
                            <div class="waves wave-1"></div>
                            <div class="waves wave-2"></div>
                            <div class="waves wave-3"></div>
                          </div>
                        </div>
                        <a href="#" class="video video-popup d-flex align-items-center justify-content-center" data-lity><i class="fa fa-play"></i></a>
                      </div>
                </div>
              

<div class="knowledge_area news_area m-50">
              <h3>Latest News</h3>
              <div class="row">

<?php
$args = array(
    'post_type' => 'post',
    'category_name' => 'news',
    'posts_per_page' => 3,
    'order' => 'ASC'
);
$the_query = new WP_Query( $args ); ?>

<?php if ( $the_query->have_posts() ) : ?>
<?php 
while ( $the_query->have_posts() ) : $the_query->the_post(); 
$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
?>
                <div class="col-lg-4 d-flex align-items-stretch">
                  <div class="knowledge_box w-100">
                    <div class="knowledge_box_inner">
                      <a href="<?php the_permalink(); ?>">
                        <div class="knowledge_thumb">
                          <img src="<?php echo $imgurl; ?>" alt="#">
                        </div>
                      </a>                      
                      <div class="knowledge_body">
                        <div class="posted"><?php echo get_the_date(); ?></div>
                        <h4><?php the_title(); ?></h4>
                        <?php the_content(); ?>
                        
                        <div class="learn-btn"><a href="<?php the_permalink(); ?>">Learn more 

                          <img src="<?php echo get_template_directory_uri(); ?>/images/rightarrow.png" alt="#">
                         </a>
                        </div>

                      </div>
                     </div>
                   </div>
                </div>
<?php endwhile; ?>
    <?php wp_reset_postdata(); ?>

<?php endif; ?>

<!--                 <div class="col-lg-4 d-flex align-items-stretch">
                  <div class="knowledge_box w-100">
                    <div class="knowledge_box_inner">
                       <a href="#">
                      <div class="knowledge_thumb">
                        <img src="images/newsthumble1.jpg" alt="#">
                      </div>
                      <div class="knowledge_body">
                        <div class="posted">2023/01/31</div>
                        <h4>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt</h4>
                        <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit sed.</p>
                        <div class="learn-btn">Learn more <img src="images/rightarrow.png" alt="#"></div>
                      </div>
                      </a>
                     </div>
                   </div>
                </div>
                <div class="col-lg-4 d-flex align-items-stretch">
                  <div class="knowledge_box w-100">
                    <div class="knowledge_box_inner">
                       <a href="#">
                      <div class="knowledge_thumb">
                        <img src="images/newsthumble2.jpg" alt="#">
                      </div>
                     <div class="knowledge_body">
                        <div class="posted">2023/02/15</div>
                        <h4>There are many vari ations of passages of Lorem Ipsum available but</h4>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece.</p>
                        <div class="learn-btn">Learn more <img src="images/rightarrow.png" alt="#"></div>
                      </div>
                      </a>
                     </div>
                   </div>
                </div> -->


              </div>
              <div class="text-center">
<?php
// Get the ID of a given category
$category_id = get_cat_ID( 'news' );

// Get the URL of this category
$category_link = get_category_link( $category_id );
?>                
                <a class="btn-outlinearea" href="<?php echo $category_link; ?>">view all news</a>
              </div>
            </div>


                <!-- inner about news stop -->
            </div>
            <!-- inner about area stop -->
          </div>
        </main>
      </div>
        
<?php get_footer(); ?>