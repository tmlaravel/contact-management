<?php
/**
* Template Name: Contact Page
*/

?>

<?php get_header(); ?>
<main class="main innermain">
          <div class="container">
            <div class="homepage-intro_container">
              <a href="<?php echo get_home_url(); ?>">
              <div class="homepage-intro_brand">
                <img src="<?php echo get_field('logo', 'option'); ?>" alt="#">
              </div>
          </a>
              <!-- breadcrumb start -->
              <nav>
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo get_home_url(); ?>">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page"><?php the_title(); ?></li>
                </ol>
              </nav>
              <!-- breadcrumb stop -->
              <!-- inner banner start -->
              <div class="inner-banner-area">
                <div class="row">
                  <div class="col-lg-6 order-2">
                <div class="inner-banner-img d-flex">
                  <img src="<?php echo get_the_post_thumbnail_url($post_id); ?>" alt="#">
                </div>
              </div>
              <div class="col-lg-6 order-1">
                <div class="inner-banner-contain">
                  <h1><?php the_title(); ?></h1>
                  <p><?php the_content(); ?></p>
                </div>
              </div>
              </div>
              </div>
              <!-- inner banner stop -->
            </div>
            <div class="inner-contact-area m-50">
                        <div class="text"><?php echo get_field('text',$post_id); ?></div>
                        <div class="inner-contact-service-box">
                            <ul>

<?php
$args = array(
'taxonomy' => 'service_cat',
'orderby' => 'name',
'order' => 'ASC',
'hide_empty' => false,
'exclude' => array(16)
);
$categories = get_categories( $args );
//echo '<pre>'; print_r(get_categories( $args ));
foreach( $categories as $category ){
  $term_link = get_term_link( $category->term_id);
  if( $category->parent == 0  && $category->name != 'Uncategorized' ){
  	$icon = get_field('category_image', $category->taxonomy . '_' . $category->term_id);
?>

 <li class="d-lg-flex align-items-center"><a href="<?php echo get_home_url(); ?>/service-form?service_name=<?php echo $category->name; ?>" class="btn-outlinearea btn-red"><?php echo $category->name; ?> Services</a>Request a <?php echo $category->name; ?> Services</li>

  
<?php }  }?>



<!--                                 <li class="d-lg-flex align-items-center"><a href="#" class="btn-outlinearea btn-red">Roofing Services</a>Request a Chimney Services
                                    Quote</li>
                                <li class="d-lg-flex align-items-center"><a href="#" class="btn-outlinearea btn-red">Roofing Services</a>Request a Gutter Services
                                    Quote</li>
                                <li class="d-lg-flex align-items-center"><a href="#" class="btn-outlinearea btn-red">Roofing Services</a>Request a Siding Services
                                    Quote</li>
                                <li class="d-lg-flex align-items-center"><a href="#" class="btn-outlinearea btn-red">Roofing Services</a>Request a Hardscapes and
                                    Masonry Quote</li>
                                <li class="d-lg-flex align-items-center"><a href="#" class="btn-outlinearea btn-red">Roofing Services</a>Request a Deck Building,
                                    Repair and Restoration Quote</li> -->

                            </ul>
                        </div>
                        <!-- inner contact faq start -->
<!--                     <div class="inner-contact-faq-area">
                        <div class="accordion" id="accordionBasic">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                        Nam libero tempore
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionBasic">
                                    <div class="accordion-body">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac iaculis nibh. Integer eget pharetra purus. In vitae diam a nulla accumsan rutrum. Aliquam bibendum interdum sapien, ac malesuada dolor condimentum sit amet. Proin ac sapien velit. Aliquam sit amet magna pharetra, dictum massa in, scelerisque lacus. Nunc rutrum ut nulla ut sagittis. Ut et leo urna.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        Voluptates repudiandae
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionBasic">
                                    <div class="accordion-body">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac iaculis nibh. Integer eget pharetra purus. In vitae diam a nulla accumsan rutrum. Aliquam bibendum interdum sapien, ac malesuada dolor condimentum sit amet. Proin ac sapien velit. Aliquam sit amet magna pharetra, dictum massa in, scelerisque lacus. Nunc rutrum ut nulla ut sagittis. Ut et leo urna.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <!-- inner contact faq stop -->
                    </div>
            </div>
            <!-- inner about area stop -->
          </div>
        </main>
      </div>        
<?php get_footer(); ?>