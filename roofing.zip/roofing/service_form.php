<?php
/**
* Template Name: Service Form Page
*/

?>

<?php get_header(); ?>
 
 <main class="main innermain">
          <div class="container">
            <div class="homepage-intro_container">
              <a href="<?php echo get_home_url(); ?>">
              <div class="homepage-intro_brand">
                <img src="<?php echo get_field('logo', 'option'); ?>" alt="#">
              </div>
          </a>
              
              
              <!-- inner banner stop -->
            </div>

            <div class="inner-service-form-area m-50">
                        <h1><?php echo $_GET['service_name']; ?> Services <br>Enquiry Form</h1>
                        <form action="">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Preferred term</label>
                                        <input type="text" class="form-control" placeholder="Preferred term">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Asset Type</label>
                                        <input type="text" class="form-control" placeholder="Asset Type">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Company Name</label>
                                        <input type="text" class="form-control" placeholder="Company Name">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>Address</label>
                                        <input type="text" class="form-control" placeholder="Address">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>Zip Code</label>
                                        <input type="text" class="form-control" placeholder="Zip Code">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>City</label>
                                        <input type="text" class="form-control" placeholder="City">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>Land</label>
                                        <div class="FormSelect">
                                            <select class="form-control">
                                                <option>Land</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Salutation</label>
                                        <div class="CheckBox">
                                            <input type="radio" id="test1" name="radio-group" checked="">
                                            <label for="test1">Mr.</label>
                                          </div>
                                          <div class="CheckBox">
                                            <input type="radio" id="test2" name="radio-group">
                                            <label for="test2">Mrs.</label>
                                          </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>First Name</label>
                                        <input type="text" class="form-control" placeholder="First Name">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>Last Name</label>
                                        <input type="text" class="form-control" placeholder="Last Name">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" class="form-control" placeholder="Email">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>Phone Number</label>
                                        <input type="email" class="form-control" placeholder="Phone Number">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Question or Comments</label>
                                        <textarea class="form-control" placeholder="Question or Comments"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                        <label class="form-check-label" for="flexCheckDefault">
                                            By submitting this form, I consent to Top Quality Roofing processing my data in accordance<br> with the following provisions. <a href="#">Top Quality Roofing privacy policy</a>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <input type="submit" class="btn-outlinearea" value="submit">
                                </div>
                            </div>
                        </form>
                    </div>
           
          </div>
        </main>
      </div>       
        
<?php get_footer(); ?>