<?php
global $post;
$id = get_the_ID(); 
$postcat = get_the_category( $id );
//echo '<pre>', print_r($postcat);
/**
 * The template for displaying all single service posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header();

?>

        <main class="main innermain">
          <div class="container">
            <div class="homepage-intro_container">
              <a href="<?php echo get_home_url(); ?>">
              <div class="homepage-intro_brand">
                <img src="<?php echo get_field('logo', 'option'); ?>" alt="#">
              </div>
          </a>
              <!-- breadcrumb start -->
              <!-- <nav>
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item"><a href="#">Roofing Services</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Roof Repair</li>
                </ol>
              </nav> -->
              <?php

$ingredients = array(
    'separator' => '<i class="fa fa-chevron-right" aria-hidden="true"></i>',
    'offset' => -3,
    'length' => 3,
);

?>



      <div class="breadcrumb">
        <?php //get_breadcrumb1(); ?>
        <?php //show_breadcrumb("service_cat","taxonomy"); ?> 
        <?php //show_breadcrumb(single_tag_title("", false),"service_cat"); 
 $home = get_bloginfo("home");
 echo '<div id="kroshki"><a href="' .home_url(). '">' .'Home'. '</a> » ';
$rd_taxonomy = 'service_cat'; // region taxonomy
$rd_terms = wp_get_post_terms( $post->ID, $rd_taxonomy, array( "fields" => "ids" ) ); // getting the term IDs
if( $rd_terms ) {
    $term_array = trim( implode( ',', (array) $rd_terms ), ' ,' );
    $neworderterms = get_terms($rd_taxonomy, 'orderby=none&include=' . $term_array );
    foreach( $neworderterms as $orderterm ) {
        echo '<a href="' . get_term_link( $orderterm ) . '">' . $orderterm->name . '</a> » ';
    }
}
the_title();
echo '</div>';

        ?>
      </div>

<?php //echo pietergoosen_breadcrumbs(); ?>
              <!-- breadcrumb stop -->
              <div class="inner-banner-area d-lg-flex justify-content-between">
                <div class="inner-banner-contain underline">
                  <h1><?php the_title(); ?></h1>
                  <?php the_content(); ?>
                </div>
              </div>
            </div>
          
          <!-- inner service details area start -->
            <div class="inner-service-details-area m-50">
                <!-- details slider start -->
                <div class="details-slider-area">
                    <div class="owl-carousel searvices-carousel details-carousel" id="details-slider">

<?php
$images = get_field('gallery',$id);
if($images){

//echo '<pre>'; print_r($images);
foreach($images AS $val){ ?>
                        <div class="details-slider">
                            <img src="<?php echo esc_url($val['sizes']['large']); ?>" alt="#" title="" />
                        </div>
<?php } }?>
                    </div>
                </div>
                <!-- details slider stop -->
                <div class="details-text-box">

<?php echo get_field('content',$id ); ?>

                </div>
                <div class="inner-contact-faq-area">
                    <div class="accordion" id="accordionBasic">

<?php
$i = 0;
    if( have_rows('list',$id) ): while ( have_rows('list',$id) ) : the_row(); 
    $i++;      
?>
        
        <div class="accordion-item">
                            <h2 class="accordion-header" id="<?php echo $i; ?>">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $i; ?>" aria-expanded="false" aria-controls="collapse<?php echo $i; ?>">
                                    <?php echo get_sub_field('title'); ?>
                                </button>
                            </h2>
                            <div id="collapse<?php echo $i; ?>" class="accordion-collapse collapse" aria-labelledby="<?php echo $i; ?>" data-bs-parent="#accordionBasic">
                                <div class="accordion-body">
                                    <p><?php echo get_sub_field('text'); ?></p>
                                </div>
                            </div>
                        </div>
<?php
    endwhile; endif;

?>                    	

                        


<!--                         <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Voluptates repudiandae
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionBasic">
                                <div class="accordion-body">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac iaculis nibh. Integer eget pharetra purus. In vitae diam a nulla accumsan rutrum. Aliquam bibendum interdum sapien, ac malesuada dolor condimentum sit amet. Proin ac sapien velit. Aliquam sit amet magna pharetra, dictum massa in, scelerisque lacus. Nunc rutrum ut nulla ut sagittis. Ut et leo urna.</p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseTwo">
                                    FAQ
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionBasic">
                                <div class="accordion-body">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac iaculis nibh. Integer eget pharetra purus. In vitae diam a nulla accumsan rutrum. Aliquam bibendum interdum sapien, ac malesuada dolor condimentum sit amet. Proin ac sapien velit. Aliquam sit amet magna pharetra, dictum massa in, scelerisque lacus. Nunc rutrum ut nulla ut sagittis. Ut et leo urna.</p>
                                </div>
                            </div>
                        </div>
 -->



                    </div>
                </div>
                <!-- other service area start -->
                <div class="other-service-area">
                    <h2>View other services in this category</h2>


                    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-3 row-cols-xxl-3">

<?php

$related = get_posts( array( 'post_type' => 'service','category__in' => wp_get_post_categories($id), 'numberposts' => 5, 'post__not_in' => array($id) ) );
if( $related ) foreach( $related as $post ) {
setup_postdata($post); ?>

        
                        <div class="col d-lg-flex align-items-stretch">
                            <div class="card inner-service-box">
                              <a href="<?php the_permalink() ?>">
                                <figure class="card-img d-flex"><img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="#"></figure>
                                <div class="card-body">
                                  <h3><?php the_title(); ?></h3>
                                  <?php the_content(); ?>
                                </div>
                              </a>
                            </div>
                          </div>
      
<?php }
wp_reset_postdata(); ?>


                    </div>
                </div>
                <!-- other service area stop -->
            </div>
            <!-- inner service details area stop -->

          </div>
        </main>
      </div>


<?php
get_footer();
