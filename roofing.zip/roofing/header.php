<?php
$post_id=$post->ID;
?>
<?php
// When checking the main website URL with the homepage set to display Latest Posts. 
?>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/responsive.css">
    <title>Top Quality Roofing home</title>
    <style type="text/css">
      
    </style>
 <?php wp_head(); ?>   
  </head>
  <body>

    <div class="main-layout">

      <div class="main_toparea">
        <header class="headerarea <?php if(!is_front_page()) {echo 'inner-header';}?>">
          <div class="header_navbar">
            <div class="header_navbarBody">
              <div class="navigation_container">
                <div class="navigation_scrollable">

                  <nav class="nav-main_nav">

                    <ul class="nav-main_list">
<?php
$args = array(
'taxonomy' => 'service_cat',
'orderby' => 'name',
'order' => 'ASC',
'hide_empty' => false,
'exclude' => array(16)
);
$categories = get_categories( $args );
//echo '<pre>'; print_r(get_categories( $args ));
foreach( $categories as $category ){
  $term_link = get_term_link( $category->term_id);
  if( $category->parent == 0  && $category->name != 'Uncategorized' ){
    $icon = get_field('category_image', $category->taxonomy . '_' . $category->term_id);
?>
                      <li><a href="<?php echo $term_link; ?>"><?php echo $category->name; ?> Services<span><img src="<?php echo get_template_directory_uri(); ?>/images/rightarrow.png" alt="#"></span></a></li>
<?php }  }?>

                      

                      <span class="nav-main-small">
<?php
$menu_name = 'Header';
$locations = get_nav_menu_locations();
$menu = wp_get_nav_menu_object( $locations[ $menu_name ] );
$menuitems = wp_get_nav_menu_items( $menu->term_id, array( 'order' => 'DESC' ) );
?>

    <?php
    $count = 0;
    $submenu = false;
    $active_class='';
    foreach( $menuitems as $item ):
        // set up title and url
        $title = $item->title;
        $link = $item->url;

        // item does not have a parent so menu_item_parent equals 0 (false)
        if ( !$item->menu_item_parent ):

        // save this id for later comparison with sub-menu items
        $parent_id = $item->ID;

      if($item->object_id == $current_page){
      $active_class='class="active"';
      }else{
      $active_class='';
      }    
    ?>
    
<li <?php echo $active_class; ?>>

<?php $has_children = $wpdb->get_var("SELECT COUNT(meta_id) FROM wp_postmeta WHERE meta_key='_menu_item_menu_item_parent' AND meta_value='".$item->ID."'"); ?>
<?php
 if ($has_children > 0) {
?>
        <a href="#">
<?php
}else{
?>
<a href="<?php echo $link; ?>">
<?php } ?>

            <span><?php echo $title; ?></span>

 <?php
 if ($has_children > 0) {
 
?>
        <span class="dropdown-icon"><i class="fa-solid fa-plus"></i></span>
<?php
}
?>           

        </a>
    <?php endif; ?>               
               
<?php if ( $parent_id == $item->menu_item_parent ): ?>

<?php if ( !$submenu ): $submenu = true; ?>
            <ul class="nav-dropdown">
            <?php endif; ?>
            
<li class="item">
                    <a href="<?php echo $link; ?>" class="title"><?php echo $title; ?></a>
                </li>
                
 <?php if ( $menuitems[ $count + 1 ]->menu_item_parent != $parent_id && $submenu ): ?>
            </ul>
            <?php $submenu = false; endif; ?>

        <?php endif; ?>
        
<?php if ( $menuitems[ $count + 1 ]->menu_item_parent != $parent_id ): ?>
    </li>                           
    <?php $submenu = false; endif; ?>

<?php $count++; endforeach; ?>



<!--                           <li><a href="#">About</a></li>
                          <li><a href="#">Contact</a></li>
                          <li><a href="#">Service</a></li>
                          <li><a href="#">Contact Us</a></li> -->


                      </span>
                    </ul>

                    
                   
                  </nav>

                </div>
              </div>
            </div>
          </div>

          <div class="header_panel" data-scroll-completed='false'>
            <button style="position: relative;" class="btn btn-primary <?php if(is_front_page()) {echo 'menu-btn';}else{echo 'menu-btn-inner';}?>" onclick="menuOpen()">
               <input type="checkbox" name="" id="" class="check">
               <div class="ham-menu">
                <span class="line line1"></span>
                <span class="line line2"></span>
                <span class="line line3"></span>
              </div>
            </button>
          </div>

<?php if(is_front_page()) { ?>
          <div class="header_body" data-scroll-speed="1">
            <div class="homepage-intro_container">
              <a href="<?php home_url(); ?>">
              <div class="homepage-intro_brand">
                <img src="<?php echo get_field('logo', 'option'); ?>" alt="#">
              </div>
              </a>
<!--               <h1>welcome to top quality Roofing</h1>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p> -->
<?php

$my_postid = $post_id;//This is page id or post id
$content_post = get_post($my_postid);
$content = $content_post->post_content;
$content = apply_filters('the_content', $content);
$content = str_replace(']]>', ']]&gt;', $content);
echo $content;

?>
              <a class="btn-outlinearea" href="#">Read More <span><img src="<?php echo get_template_directory_uri(); ?>/images/rightarrow.png" alt="#"></span></a>
            </div>
          </div>
<?php } ?>
          <div class="header_cover" data-scroll-completed='false'>
            <div class="header_coverFrame">
              <div class="header_coverMas">
              <video class="header_coverVideo__cLNW8" loop="" muted="" autoplay="">
                <source src="<?php echo get_field('header_cover_video',21); ?>" type="video/mp4">
              </video>
            </div>
            </div>
          </div>

        </header>