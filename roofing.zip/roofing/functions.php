<?php

register_nav_menus( array(
    'Header'   => __( 'Header Menu', 'roofing' ),
    'secondary' => __( 'Secondary Menu', 'roofing' )
) );

add_theme_support( 'post-thumbnails' );

add_theme_support( 'post-formats',  array( 'aside', 'gallery', 'quote', 'image', 'video' ) );


if( function_exists('acf_add_options_page') ) {
    
    acf_add_options_page(array(
        'page_title'    => 'Theme General Settings',
        'menu_title'    => 'Theme Settings',
        'menu_slug'     => 'theme-general-settings',
        'capability'    => 'edit_posts',
        'redirect'      => false
    ));
    
}

function get_breadcrumb() {
    echo '<a href="'.home_url().'" rel="nofollow">Home</a>';
    if (is_category() || is_single()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
        the_category(' &bull; ');
            if (is_single()) {
                echo " &nbsp;&nbsp;&#187;&nbsp;&nbsp; ";
                the_title();
            }
    } elseif (is_page()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
        echo the_title();
    } elseif (is_search()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;Search Results for... ";
        echo '"<em>';
        echo the_search_query();
        echo '</em>"';
    }
}


?>

<?php

/**
 * Checks if a string ends with a given substring.
 * Backward compatibility for PHP < 8.0.0.
 *
 * @since   1.2.0
 * @param   String  $haystack   The string to search in.
 * @param   String  $needle     The substring to search for in the haystack.
 * @return  Boolean
 */
if ( ! function_exists( 'backward_compatibility_str_ends_with' ) ) {

    function backward_compatibility_str_ends_with( $haystack, $needle ) {

        $length = strlen( $needle );

        if ( ! $length ) {

            return true;

        };

        return substr( $haystack, -$length ) === $needle;

    };

};

/**
 * Determine if a string contains a given substring.
 * Backward compatibility for PHP < 8.0.0.
 *
 * @since   1.2.0
 * @param   String  $haystack   The string to search in.
 * @param   String  $needle     The substring to search for in the haystack.
 * @return  Boolean
 */
if ( ! function_exists( 'backward_compatibility_str_contains' ) ) {

    function backward_compatibility_str_contains( $haystack, $needle ) {

        if ( strpos( $haystack, $needle ) !== false ) {

            return true;

        };

    };

};

/**
 * Retrieve the crumbs.
 * 
 * @since   1.0.0
 * @return  Array   Crumbs array.
 */
if ( ! function_exists( 'get_the_crumbs' ) ) {

    function get_the_crumbs() {

        /**
         * $_SERVER["REQUEST_SCHEME"] seems to be UNRELIABLE.
         * 
         * Article "Is $_SERVER['REQUEST_SCHEME'] reliable?".
         * @see https://stackoverflow.com/a/18008178/3645650
         * 
         * $_SERVER['REQUEST_SCHEME'] is a native variable of Apache web server since its version 2.4.
         * Naturally, if a variable is not set by the server, PHP will not include it in its global array $_SERVER.
         * 
         * An alternative to $_SERVER['REQUEST_SCHEME'] is $_SERVER['HTTPS'] which set to a non-empty value if the script was queried through the HTTPS protocol.
         * 
         * Article "How to find out if you're using HTTPS without $_SERVER['HTTPS']".
         * @see https://stackoverflow.com/a/16076965/3645650
         */

        if ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] == 'on' ) {

            $server_scheme = 'https';

        } elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || ! empty( $_SERVER['HTTP_X_FORWARDED_SSL'] ) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on' ) {
            
            $server_scheme = 'https';

        } else {

            $server_scheme = 'http';

        };
        
        /**
         * $_SERVER["REQUEST_URI"] seems to be RELIABLE.
         * $_SERVER['REQUEST_URI'] will not be empty in WordPress, because it is filled in wp_fix_server_vars() (file wp-includes/load.php).
         * 
         * Article "Is it safe to use $_SERVER['REQUEST_URI']?".
         * @see https://wordpress.stackexchange.com/a/110541/190376
         */
        $server_uri = $_SERVER['REQUEST_URI'];

        /**
         * $_SERVER["HTTP_HOST"] seems to be RELIABLE.
         * 
         * Article "How reliable is HTTP_HOST?".
         * @see https://stackoverflow.com/a/4096246/3645650
         */
        $server_host = $_SERVER["HTTP_HOST"];

        if ( backward_compatibility_str_contains( $server_uri, '?' ) ) {

            $server_uri = substr( $server_uri, 0, strpos( $server_uri, '?' ) );

        };

        if ( backward_compatibility_str_ends_with( $server_uri, '/' ) ) {

            $server_uri = explode( '/', substr( $server_uri, 1, -1 ) );

        } else {

            $server_uri = explode( '/', substr( $server_uri, 1 ) );

        };

        $crumbs = array();

        foreach ( $server_uri as $crumb ) {

            $slug = esc_html( urldecode( $crumb ) );

            $url = esc_url( $server_scheme . '://' . $server_host . '/' . substr( implode( '/', $server_uri ), 0, strpos( implode( '/', $server_uri ), $crumb ) ) . $crumb. '/' );

            array_push( $crumbs, 
                array(
                    'slug' => $slug,
                    'url' => $url,
                )
            );

        };

        /**
         * WordPress, by default, doesn't generate a taxonomy index, meaning https://.../taxonomy will redirect to a 404.
         * Any request needs to be made against a term. eg: https://.../taxonomy/term will redirect to taxonomy.php.
         * Therefore we need to remove the taxonomy slug from the crumbs array to avoid displaying a link to a 404.
         * 
         * We round up all taxonomies through get_taxonomies(). 
         * @see https://developer.wordpress.org/reference/functions/get_taxonomies/
         * 
         * Through array_filter we filter-out any matching crumbs.
         * @see https://www.php.net/manual/en/function.array-filter.php
         */
        $banned_slugs = array();

        $taxonomies = get_taxonomies( 
            array(
                'public' => true,
            ),
            'objects'
        );
        
        foreach ( $taxonomies as $taxonomy ) {

            array_push( $banned_slugs, $taxonomy->name );
            
            if ( isset( $taxonomy->rewrite['slug'] ) ) {
            
                array_push( $banned_slugs, $taxonomy->rewrite['slug'] );
            
            };

        };

        $banned_crumbs = array();

        foreach ( $banned_slugs as $banned_slug ) {

            $slug = esc_html( $banned_slug );

            $url = esc_url( $server_scheme . '://' . $server_host . '/' . substr( implode( '/', $server_uri ), 0, strpos( implode( '/', $server_uri ), $banned_slug ) ) . $banned_slug. '/' );

            array_push( $banned_crumbs, 
                array(
                    'slug' => $slug,
                    'url' => $url,
                )
            );

        };

        $crumbs = array_filter( $crumbs, function( $crumb ) use ( $banned_slugs ) {

            if ( ! in_array( $crumb['slug'], $banned_slugs ) && ! in_array( $crumb['url'], $banned_slugs ) ) {

                return ! in_array( $crumb['slug'], $banned_slugs );

            };

        } );

        return $crumbs;

    };

};

/**
 * Display the bread, a formatted crumbs list.
 * 
 * @since   1.0.0
 * @param   Array   $ingredients                    The bread arguments.
 * @param   Array   $ingredients['crumbs']          The crumbs array. Default to get_the_crumbs().
 * @param   Array   $ingredients['root']            Root crumb. Default to null.
 * @param   String  $ingredients['root']['slug']    Root crumb slug.
 * @param   String  $ingredients['root']['url']     Root crumb url.
 * @param   String  $ingredients['separator']       The crumb's separator.
 * @param   Integer $ingredients['offset']          Crumbs offset. Accept positive/negative Integer. Default to "0". Refer to array_slice, https://www.php.net/manual/en/function.array-slice.php.
 * @param   Integer $ingredients['length']          Crumbs length. Accept positive/negative Integer. Default to "null". Refer to array_slice, https://www.php.net/manual/en/function.array-slice.php.
 * @return  Array   The formatted crumbs list.
 */
if ( ! function_exists( 'the_bread' ) ) {

    function the_bread( $ingredients = array() ) {

        if ( empty( $ingredients['crumbs'] ) ) {
        
            $crumbs = get_the_crumbs();
            
        } else {
        
            $crumbs = $ingredients['crumbs'];
            
        };

        if ( empty( $ingredients['root'] ) ) {
        
            $root = null;
            
        } else {
        
            $root = $ingredients['root'];
            
        };
        
        if ( empty( $ingredients['offset'] ) ) {
        
            $offset = 0;
            
        } else {
        
            $offset = $ingredients['offset'];
            
        };
               
        if ( empty( $ingredients['length'] ) ) {
        
            $length = null;
            
        } else {
        
            $length = $ingredients['length'];
            
        };

        /**
         * Handling the root crumb case. 
         * Prepend one or more elements to the beginning of an array.
         * @see https://www.php.net/manual/en/function.array-unshift.php
         */
        if ( ! empty( $root ) ) {

            array_unshift( $crumbs, $ingredients['root'] );

        };
        
        /**
         * Handling the length case.
         * Extract a slice of the array.
         * @see https://www.php.net/manual/en/function.array-slice.php
         */
        $crumbs = array_slice( $crumbs, $offset, $length );

        if ( ! empty( $crumbs ) ) {

            echo '<ol class="🍞 bread" itemscope itemtype="https://schema.org/BreadcrumbList">';

            $i = 0;
            
            foreach ( $crumbs as $crumb ) {

                $i++;

                /**
                 * Unparsing the slug.
                 */
                if ( url_to_postid( $crumb['url'] ) ) {

                    $title = get_the_title( url_to_postid( $crumb['url'] ) );

                } elseif ( get_page_by_path( $crumb['slug'] ) ) {

                    $title = get_the_title( get_page_by_path( $crumb['slug'] ) );

                } else {
  
                    $title = ucfirst( str_replace( '-', ' ', $crumb['slug'] ) );

                };

                echo '<li class="crumb" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                    <a itemprop="item" href="' . $crumb['url'] . '">
                        <span itemprop="name">' . $title . '</span>
                    </a>
                    <meta itemprop="position" content="' . $i . '">
                </li>';

                if ( $i !== sizeof( $crumbs ) && ! empty( $ingredients['separator'] ) ) {

                    echo $ingredients['separator'];

                };
    
            };
    
            echo '</ol>';

        };

    };

};



function get_breadcrumb1() {

    echo '&#127962; <a href="'.home_url().'" rel="nofollow">Home</a>';

    if (is_category() || is_single()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
        the_category(' &#187; ');
        if (is_single()) {
            echo " &nbsp;&nbsp;&#187;&nbsp;&nbsp; ";
            the_title();
        }
    } elseif (is_page()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
        echo the_title();
    } elseif (is_search()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;Search Results for... ";
        echo '"<em>';
        echo the_search_query();
        echo '</em>"';
    }
}



if ( ! function_exists( 'pietergoosen_breadcrumbs' ) ) :

    function pietergoosen_breadcrumbs() {
          /* === OPTIONS === */
        $text['home']     = _x( 'Home', 'Home', 'pietergoosen' ); // text for the 'Home' link
     $text['category'] = __( 'Archive by Category "%s"', 'pietergoosen' );  // text for a category page
     $text['search']   = __( 'Search Results for "%s" Query', 'pietergoosen' ); // text for a search results page
     $text['tag']      = __( 'Posts Tagged "%s"', 'pietergoosen' );  // text for a tag page
     $text['author']   = __( 'Posts Posted by %s', 'pietergoosen' ); // text for an author page
     $text['404']      = __( 'Error 404', 'pietergoosen' );  // text for the 404 page

     $show_current   = 1; // 1 - show current post/page/category title in breadcrumbs, 0 - don't show
     $show_on_home   = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show
     $show_home_link = 1; // 1 - show the 'Home' link, 0 - don't show
     $show_title     = 1; // 1 - show the title for the links, 0 - don't show
     $delimiter      = ' &raquo; '; // delimiter between crumbs
     $before         = '<span class="current">'; // tag before the current crumb
     $after          = '</span>'; // tag after the current crumb
     /* === END OF OPTIONS === */

     global $post;
        $here_text    = __('You are currently here! &nbsp;&raquo;&nbsp;', 'pietergoosen');
     $home_link    = home_url('/');
     $link_before  = '<span typeof="v:Breadcrumb">';
     $link_after   = '</span>';
     $link_attr    = ' rel="v:url" property="v:title"';
     $link         = $link_before . '<a' . $link_attr . ' href="%1$s">%2$s</a>' . $link_after;
        if (isset($post)){
            $parent_id    = $parent_id_2  = $post->post_parent;
        }
     $frontpage_id = get_option('page_on_front');

     if (is_home() || is_front_page()) {

            if ($show_on_home == 1) echo '<div class="breadcrumb"><a href="' . $home_link . '">' . $text['home'] . '</a></div>';

        } else {

         echo '<div class="breadcrumb">';
         if ($show_home_link == 1) {
             echo  $here_text . '<a href="' . $home_link . '" rel="v:url" property="v:title">' . $text['home'] . '</a>';
             if ($frontpage_id == 0 || $parent_id != $frontpage_id) echo $delimiter;
         }

         if ( is_category() ) {
             $this_cat = get_category(get_query_var('cat'), false);
             if ($this_cat->parent != 0) {
                 $cats = get_category_parents($this_cat->parent, TRUE, $delimiter);
                 if ($show_current == 0) $cats = preg_replace("#^(.+)$delimiter$#", "$1", $cats);
                 $cats = str_replace('<a', $link_before . '<a' . $link_attr, $cats);
                 $cats = str_replace('</a>', '</a>' . $link_after, $cats);
                 if ($show_title == 0) $cats = preg_replace('/ title="(.*?)"/', '', $cats);
                 echo $cats;
             }
                if ($show_current == 1) echo $before . sprintf($text['category'], single_cat_title('', false)) . $after;

          } elseif ( is_search() ) {
              echo $before . sprintf($text['search'], get_search_query()) . $after;

          } elseif ( is_day() ) {
             echo sprintf($link, get_year_link(get_the_time('Y')), get_the_time('Y')) . $delimiter;
             echo sprintf($link, get_month_link(get_the_time('Y'),get_the_time('m')), get_the_time('F')) . $delimiter;
             echo $before . get_the_time('d') . $after;

         } elseif ( is_month() ) {
             echo sprintf($link, get_year_link(get_the_time('Y')), get_the_time('Y')) . $delimiter;
             echo $before . get_the_time('F') . $after;

          } elseif ( is_year() ) {
              echo $before . get_the_time('Y') . $after;

          } elseif ( is_single() && !is_attachment() ) {
                if ( get_post_type() != 'post' ) {
                    $post_type = get_post_type_object(get_post_type());
                    $slug = $post_type->rewrite;
                    printf($link, $home_link . '/' . $slug['slug'] . '/', $post_type->labels->singular_name);
                    if ($show_current == 1) echo $delimiter . $before . get_the_title() . $after;
                } else {
                    $cat = get_the_category(); $cat = $cat[0];
                    $cats = get_category_parents($cat, TRUE, $delimiter);
                    if ($show_current == 0) $cats = preg_replace("#^(.+)$delimiter$#", "$1", $cats);
                    $cats = str_replace('<a', $link_before . '<a' . $link_attr, $cats);
                    $cats = str_replace('</a>', '</a>' . $link_after, $cats);
                    if ($show_title == 0) $cats = preg_replace('/ title="(.*?)"/', '', $cats);
                    echo $cats;
                    if ($show_current == 1) echo $before . get_the_title() . $after;
                }

         } elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
             $post_type = get_post_type_object(get_post_type());
             echo $before . $post_type->labels->singular_name . $after;

         } elseif ( is_attachment() ) {
               $parent = get_post($parent_id);
                $cat = get_the_category($parent->ID); $cat = $cat[0];
                $cats = get_category_parents($cat, TRUE, $delimiter);
                $cats = str_replace('<a', $link_before . '<a' . $link_attr, $cats);
                $cats = str_replace('</a>', '</a>' . $link_after, $cats);
                if ($show_title == 0) $cats = preg_replace('/ title="(.*?)"/', '', $cats);
                echo $cats;
              printf($link, get_permalink($parent), $parent->post_title);
              if ($show_current == 1) echo $delimiter . $before . get_the_title() . $after;

            } elseif ( is_page() && !$parent_id ) {
                if ($show_current == 1) echo $before . get_the_title() . $after;

            } elseif ( is_page() && $parent_id ) {
                if ($parent_id != $frontpage_id) {
                    $breadcrumbs = array();
                    while ($parent_id) {
                        $page = get_page($parent_id);
                        if ($parent_id != $frontpage_id) {
                            $breadcrumbs[] = sprintf($link, get_permalink($page->ID), get_the_title($page->ID));
                        }
                        $parent_id = $page->post_parent;
                    }
                   $breadcrumbs = array_reverse($breadcrumbs);
                   for ($i = 0; $i < count($breadcrumbs); $i++) {
                       echo $breadcrumbs[$i];
                       if ($i != count($breadcrumbs)-1) echo $delimiter;
                   }
              }
             if ($show_current == 1) {
                 if ($show_home_link == 1 || ($parent_id_2 != 0 && $parent_id_2 != $frontpage_id)) echo $delimiter;
                 echo $before . get_the_title() . $after;
             }

          } elseif ( is_tag() ) {
             echo $before . sprintf($text['tag'], single_tag_title('', false)) . $after;

          } elseif ( is_author() ) {
               global $author;
               $userdata = get_userdata($author);
              echo $before . sprintf($text['author'], $userdata->display_name) . $after;

           } elseif ( is_404() ) {
               echo $before . $text['404'] . $after;
           }

          if ( get_query_var('paged') ) {
              if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
             echo __('&nbsp;&raquo;&nbsp; Page', 'pietergoosen') . ' ' . get_query_var('paged');
             if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
         }

           echo '</div><!-- .breadcrumbs -->';

        }
    }

endif; 



add_action( 'rest_api_init', function() {
  register_rest_route( 'myplugin/v2', '/get-notification', [
    'methods'               => 'GET',
    'callback'              => 'get_notification',
    'permission_callback'   => '__return_true',
  ] );
} );


function get_notification( WP_REST_Request $request ) {

     global $wpdb;



    $success_message            = 'SUCCESS';
    $respond['status']          = true;
    $respond['response_data']   = 'hi';
    $respond['message']         = $success_message;



 return $respond;
}

function show_breadcrumb($name,$type){
    $list = "";
    $home = get_bloginfo("home");
    if ($type && $name){
        $ans = get_term_by('name', $name, $type);
        $parentID=$ans->parent;
        while ($parentID > 0){
            $parent = get_term_by('id', $parentID, $type);
            $url = $home."/".$type."/".$parent->slug;
            $list = "<li><a href='".$url."'>".$parent->name."</a></li>".$list;
            $parentID = $parent->parent;
        }
        $url = $home."/".$type."/".$ans->slug;
        $list = $list."<li>".$ans->name."</li>";
    }   
  
    if ($list) echo "<ul><li><a href='$home'>Home</a></li>".$list."</ul>";
}