<?php
/**
* Template Name: Home Page
*/

?>

<?php get_header(); ?>
        <main class="main">
          <div class="container">
<?php $about = get_field('about_us_area',$post_id); ?>
            <div class="about-area">
              <div class="row">
                <div class="col-lg-6">
                  <div class="aboutleft">
                    <h2><?php echo $about['content']; ?></h2>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="aboutright">
                    <div class="thumble">
                      <img src="<?php echo $about['image']; ?>" alt="#">
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="searvices_sliderarea_total m-50">
            <div class="searvices_sliderarea">
              <div class="owl-carousel searvices-carousel" id="searvices-slider">


<?php
$args = array(
'taxonomy' => 'service_cat',
'orderby' => 'name',
'order' => 'ASC',
'hide_empty' => false,
'exclude' => array(16)
);
$categories = get_categories( $args );
//echo '<pre>'; print_r(get_categories( $args ));
foreach( $categories as $category ){
  $term_link = get_term_link( $category->term_id);
  if( $category->parent == 0  && $category->name != 'Uncategorized' ){
  	$icon = get_field('category_image', $category->taxonomy . '_' . $category->term_id);
?>

            <div class="searvicesthumble">
            <a href="<?php echo $term_link; ?>">
              <img src="<?php echo $icon; ?>" alt="#">
              <h4><?php echo $category->name; ?></h4>
            </a>
		</div>
<?php }  }?> 


<!--                 <div class="searvicesthumble">
                  <img src="images/searvicesthum2.jpg" alt="#">
                  <h4>Chimney</h4>
                </div>
                <div class="searvicesthumble">
                  <img src="images/searvicesthum3.jpg" alt="#">
                  <h4>Gutter</h4>
                </div>
                <div class="searvicesthumble">
                  <img src="images/searvicesthum4.jpg" alt="#">
                  <h4>Masonry</h4>
                </div>
                <div class="searvicesthumble">
                  <img src="images/searvicesthum1.jpg" alt="#">
                  <h4>Roofing</h4>
                </div>
                <div class="searvicesthumble">
                  <img src="images/searvicesthum2.jpg" alt="#">
                  <h4>Chimney</h4>
                </div>
                <div class="searvicesthumble">
                  <img src="images/searvicesthum3.jpg" alt="#">
                  <h4>Gutter</h4>
                </div>
                <div class="searvicesthumble">
                  <img src="images/searvicesthum4.jpg" alt="#">
                  <h4>Masonry</h4>
                </div> -->


              </div>
            </div>
            <div class="text-center ptextbox">
              <p><?php echo get_field('request_a_quote_text',$post_id); ?></p>
               <a class="btn-outlinearea" href="<?php echo get_field('request_a_quote_button_link',$post_id); ?>"><?php echo get_field('request_a_quote_button_text',$post_id); ?></a>
            </div>
          </div>
            <div class="howhelpe_area m-50">
               <div class="howhelpe_area_top">
<?php
$hero = get_field('how_can_we_help_you');
?>                
                 <h3><?php echo $hero['text']; ?></h3>
                 <div class="row">

<?php

if( have_rows('how_can_we_help_you',$post_id) ): while ( have_rows('how_can_we_help_you',$post_id) ) : the_row(); 

    if( have_rows('first_area',$post_id) ): while ( have_rows('first_area',$post_id) ) : the_row(); 
?>          

        
      <div class="col-lg-3 d-flex align-items-stretch">
      <div class="howhelpe-topcard">
      <div class="icon">
      <img src="<?php echo get_sub_field('icon'); ?>" alt="#">
      </div>
      <div class="howhelpe-topcardbody">
      <h5><?php echo get_sub_field('title'); ?></h5>
      <p><?php echo get_sub_field('content'); ?></p>
      </div>
      </div>
      </div>

<?php
    endwhile; endif;

endwhile; endif;

?>




<!--                    <div class="col-lg-3 d-flex align-items-stretch">
                     <div class="howhelpe-topcard">
                       <div class="icon">
                         <img src="images/helpicon2.png" alt="#">
                       </div>
                       <div class="howhelpe-topcardbody">
                        <h5>Leasing</h5>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock,</p>
                      </div>
                     </div>
                   </div>
                   <div class="col-lg-3 d-flex align-items-stretch">
                     <div class="howhelpe-topcard">
                       <div class="icon">
                         <img src="images/helpicon3.png" alt="#">
                       </div>
                       <div class="howhelpe-topcardbody">
                        <h5>Maintenance & Repair</h5>
                        <p>Lorem Ipsum is simply dummy text of the printing and type setting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>
                      </div>
                     </div>
                   </div>
                   <div class="col-lg-3 d-flex align-items-stretch">
                     <div class="howhelpe-topcard">
                       <div class="icon">
                         <img src="images/helpicon4.png" alt="#">
                       </div>
                       <div class="howhelpe-topcardbody">
                        <h5>Equipment</h5>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock,</p>
                      </div>
                     </div>
                   </div> -->



                 </div>
               </div>
               <div class="howhelpe_area_bottom">
                <div class="row">
<?php

if( have_rows('how_can_we_help_you',$post_id) ): while ( have_rows('how_can_we_help_you',$post_id) ) : the_row(); 

    if( have_rows('second_area',$post_id) ): while ( have_rows('second_area',$post_id) ) : the_row(); 
?> 
        <div class="col-lg-6 d-flex align-items-stretch">
                    <div class="howhelpe_bcardbox w-100">
                      <div class="thumble">
                        <img src="<?php echo get_sub_field('image'); ?>" alt="#">
                      </div>
                      <div class="howhelpe-body">
                        <h3><?php echo get_sub_field('title'); ?></h3>
                        <p><?php echo get_sub_field('content'); ?></p>
                        <ul>
<?php                          
    if( have_rows('link_area',$post_id) ): 
      while ( have_rows('link_area',$post_id) ) : the_row(); 
?> 
<li><a href="<?php echo get_sub_field('link'); ?>"><?php echo get_sub_field('link_text'); ?><span><img src="<?php echo get_template_directory_uri(); ?>/images/rightarrow.png" alt="#"></span></a></li>
<?php  endwhile; endif;  ?>                          
<!-- 
                          <li><a href="#">There are many variations<span><img src="<?php echo get_template_directory_uri(); ?>/images/rightarrow.png" alt="#"></span></a></li>
                          <li><a href="#">Letraset sheets containing Lore<span><img src="<?php echo get_template_directory_uri(); ?>/images/rightarrow.png" alt="#"></span></a></li>
                          <li><a href="#">perspiciatis unde omnis<span><img src="<?php echo get_template_directory_uri(); ?>/images/rightarrow.png" alt="#"></span></a></li> -->

                        </ul>
                      </div>
                    </div>
                  </div>
<?php
    endwhile; endif;

endwhile; endif;

?>
                  

<!--                   <div class="col-lg-6 d-flex align-items-stretch">
                    <div class="howhelpe_bcardbox w-100">
                      <div class="thumble">
                        <img src="images/twothumble2.jpg" alt="#">
                      </div>
                      <div class="howhelpe-body">
                        <h3>Excepteur sint occaecat cupidatat</h3>
                        <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam.</p>
                        <ul>
                          <li><a href="#">Various versions have<span><img src="images/rightarrow.png" alt="#"></span></a></li>
                          <li><a href="#">There are many variations<span><img src="images/rightarrow.png" alt="#"></span></a></li>
                          <li><a href="#">Letraset sheets containing Lore<span><img src="images/rightarrow.png" alt="#"></span></a></li>
                          <li><a href="#">perspiciatis unde omnis<span><img src="images/rightarrow.png" alt="#"></span></a></li>
                        </ul>
                      </div>
                    </div>
                  </div> -->


                </div>
              </div>
            </div>
            <div class="location_area m-50">
               <h3>Latest News</h3>
               <h4>There are many variations of pation</h4>
               <div class="mapbox">
                 <div class="mapimg">
                   <img src="<?php echo get_template_directory_uri(); ?>/images/mapimg.jpg" alt="#">
                 </div>
               </div>
               <div class="location-finderarea">
                 <div class="location-finderleft">
                   <h5>Find a service location near <br>you!</h5>
                   <p>There are more than 130 TIP locations</p>
                 </div>
                 <div class="location-finderright">
                   <input class="form-control" type="text" name="city" placeholder="City">
                   <div class="locationbin d-flex justify-content-end align-items-center">
                     <h6>Our locations</h6>
                     <button><i class="fa-solid fa-magnifying-glass"></i></button>
                   </div>
                 </div>
               </div>
            </div>

             <div class="knowledge_area news_area m-50">
              <h3>Latest News</h3>
              <div class="row">

<?php
$args = array(
    'post_type' => 'post',
    'category_name' => 'news',
    'posts_per_page' => 3,
    'order' => 'ASC'
);
$the_query = new WP_Query( $args ); ?>

<?php if ( $the_query->have_posts() ) : ?>
<?php 
while ( $the_query->have_posts() ) : $the_query->the_post(); 
$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
?>
                <div class="col-lg-4 d-flex align-items-stretch">
                  <div class="knowledge_box w-100">
                    <div class="knowledge_box_inner">
                      <a href="<?php the_permalink(); ?>">
                        <div class="knowledge_thumb">
                          <img src="<?php echo $imgurl; ?>" alt="#">
                        </div>
                      </a>                      
                      <div class="knowledge_body">
                        <div class="posted"><?php echo get_the_date(); ?></div>
                        <h4><?php the_title(); ?></h4>
                        <p><?php echo get_field('short_description'); ?></p>
                        
                        <div class="learn-btn"><a href="<?php the_permalink(); ?>">Learn more 

                          <img src="<?php echo get_template_directory_uri(); ?>/images/rightarrow.png" alt="#">
                         </a>
                        </div>

                      </div>
                     </div>
                   </div>
                </div>
<?php endwhile; ?>
    <?php wp_reset_postdata(); ?>

<?php endif; ?>

<!--                 <div class="col-lg-4 d-flex align-items-stretch">
                  <div class="knowledge_box w-100">
                    <div class="knowledge_box_inner">
                       <a href="#">
                      <div class="knowledge_thumb">
                        <img src="images/newsthumble1.jpg" alt="#">
                      </div>
                      <div class="knowledge_body">
                        <div class="posted">2023/01/31</div>
                        <h4>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt</h4>
                        <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit sed.</p>
                        <div class="learn-btn">Learn more <img src="images/rightarrow.png" alt="#"></div>
                      </div>
                      </a>
                     </div>
                   </div>
                </div>
                <div class="col-lg-4 d-flex align-items-stretch">
                  <div class="knowledge_box w-100">
                    <div class="knowledge_box_inner">
                       <a href="#">
                      <div class="knowledge_thumb">
                        <img src="images/newsthumble2.jpg" alt="#">
                      </div>
                     <div class="knowledge_body">
                        <div class="posted">2023/02/15</div>
                        <h4>There are many vari ations of passages of Lorem Ipsum available but</h4>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece.</p>
                        <div class="learn-btn">Learn more <img src="images/rightarrow.png" alt="#"></div>
                      </div>
                      </a>
                     </div>
                   </div>
                </div> -->


              </div>
              <div class="text-center">

<?php
// Get the ID of a given category
$category_id = get_cat_ID( 'news' );

// Get the URL of this category
$category_link = get_category_link( $category_id );
?>


                <a class="btn-outlinearea" href="<?php echo $category_link; ?> ">view all news</a>
              </div>
            </div>

            <div class="knowledge_area m-50">
              <h3>Latest Knowledge</h3>
              <div class="row">
<?php
$args = array(
    'post_type' => 'post',
    'category_name' => 'knowledge',
    'posts_per_page' => 3,
    'order' => 'ASC'
);
$the_query = new WP_Query( $args ); ?>

<?php if ( $the_query->have_posts() ) : ?>
<?php 
while ( $the_query->have_posts() ) : $the_query->the_post(); 
$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
?>
                <div class="col-lg-4 d-flex align-items-stretch">
                  <div class="knowledge_box w-100">
                    <div class="knowledge_box_inner">
                       <a href="<?php the_permalink(); ?>">
                      <div class="knowledge_thumb">
                        <img src="<?php echo $imgurl; ?>" alt="#">
                      </div>
                      </a>
                      <div class="card_badgeText"><span>Knowledge Article</span></div>
                      <div class="knowledge_body">
                        <h4><?php the_title(); ?></h4>
                        <p><?php echo get_field('short_description'); ?></p>
                        <div class="learn-btn">
                          <a href="<?php the_permalink(); ?>">
                          Learn more <img src="<?php echo get_template_directory_uri(); ?>/images/rightarrow.png" alt="#">
                          </a>
                        </div>
                      </div>
                      
                     </div>
                   </div>
                </div>
<?php endwhile; ?>
    <?php wp_reset_postdata(); ?>

<?php endif; ?>

<!--                 <div class="col-lg-4 d-flex align-items-stretch">
                  <div class="knowledge_box w-100">
                    <div class="knowledge_box_inner">
                       <a href="#">
                      <div class="knowledge_thumb">
                        <img src="images/knowledgethumb1.jpg" alt="#">
                      </div>
                      <div class="card_badgeText"><span>Knowledge Article</span></div>
                      <div class="knowledge_body">
                        <h4>Excepteur sint occaecat cupidatat non proident, sunt in culp</h4>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece.</p>
                        <div class="learn-btn">Learn more <img src="images/rightarrow.png" alt="#"></div>
                      </div>
                      </a>
                     </div>
                   </div>
                </div>
                <div class="col-lg-4 d-flex align-items-stretch">
                  <div class="knowledge_box w-100">
                    <div class="knowledge_box_inner">
                       <a href="#">
                      <div class="knowledge_thumb">
                        <img src="images/knowledgethumb2.jpg" alt="#">
                      </div>
                      <div class="card_badgeText"><span>Knowledge Article</span></div>
                      <div class="knowledge_body">
                        <h4>consequuntur magni dolores eos qui ratione voluptatem sequ</h4>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece.</p>
                        <div class="learn-btn">Learn more <img src="images/rightarrow.png" alt="#"></div>
                      </div>
                      </a>
                     </div>
                   </div>
                </div> -->



              </div>
              <div class="text-center">
<?php
// Get the ID of a given category
$category_id1 = get_cat_ID( 'knowledge' );

// Get the URL of this category
$category_link1 = get_category_link( $category_id1 );
?>                
                <a class="btn-outlinearea" href="<?php echo $category_link1; ?>">view all knowlwdge article</a>
              </div>
            </div>
          </div>
        </main>
      </div>
<?php get_footer(); ?>