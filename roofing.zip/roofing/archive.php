<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header();

$description = get_the_archive_description();
$obj = get_queried_object();
//echo '<pre>'; print_r($obj);
$cat_slug = $obj->slug;

?>

<?php if ( have_posts() ) { ?>
<main class="main innermain">
          <div class="container">
            <div class="homepage-intro_container">
              <a href="<?php echo get_home_url(); ?>">
              <div class="homepage-intro_brand">
                <img src="<?php echo get_field('logo', 'option'); ?>" alt="#">
              </div>
          </a> 
              <!-- breadcrumb start -->
              <nav>
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page"><?php single_cat_title(); ?> <?php if($cat_slug!='news' && $cat_slug!='knowledge'){echo 'Services';} ?></li>
                </ol>
              </nav>
              <!-- <div class="breadcrumb"><?php get_breadcrumb(); ?></div> -->
              <!-- breadcrumb stop -->
              <!-- inner banner start -->
              <div class="inner-banner-area">
                <div class="row">
                  <div class="col-lg-6 order-2">
                <div class="inner-banner-img d-flex">
                	<?php
                	$category = get_queried_object();
$tn_id = $category->term_id;
$icon = get_field('category_image', 'service_cat' . '_' . $tn_id);
                	?>
                  <img src="<?php echo $icon; ?>" alt="#">
                </div>
              </div>
              <div class="col-lg-6 order-1">
                <div class="inner-banner-contain">
                  <h1><?php single_cat_title(); ?> <?php if($cat_slug!='news' && $cat_slug!='knowledge'){echo 'Services';} ?></h1>
                  <p><?php echo wp_kses_post( wpautop( $description ) ); ?></p>
                </div>
              </div>
              </div>
              </div>
              <!-- inner banner stop -->
            </div>
           <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-3 row-cols-xxl-3 m-50">

<?php while ( have_posts() ) : ?>
	<?php the_post(); ?>
              <div class="col d-lg-flex align-items-stretch">
                <div class="card inner-service-box">
                  <a href="<?php the_permalink(); ?>">
                    <figure class="card-img d-flex"><img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="#"></figure>
                    <div class="card-body">
                      <h3><?php the_title(); ?></h3>
                      <?php the_content(); ?>
                    </div>
                  </a>
                </div>
              </div>
<?php endwhile; ?>



            </div>
          </div>
        </main>
      </div>
<?php } ?>
<?php
get_footer();
