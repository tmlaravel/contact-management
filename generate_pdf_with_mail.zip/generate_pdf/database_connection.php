<?php
$hostname = "localhost";
$username = "shinerweb_user";
$password = "vEo&5(@~F-R(";  
$database = "shinerweb_db";   
$con=mysqli_connect($hostname,$username,$password,$database);    
?>   